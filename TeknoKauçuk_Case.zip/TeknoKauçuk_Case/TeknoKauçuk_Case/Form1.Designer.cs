﻿namespace TeknoKauçuk_Case
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
			this.txt_sayi1 = new System.Windows.Forms.TextBox();
			this.txt_sayi2 = new System.Windows.Forms.TextBox();
			this.txt_sayi3 = new System.Windows.Forms.TextBox();
			this.btn_sonuc = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.lbl_sonuc = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.button2 = new System.Windows.Forms.Button();
			this.button1 = new System.Windows.Forms.Button();
			this.btn_dosya = new System.Windows.Forms.Button();
			this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			this.txt_fibosayi = new System.Windows.Forms.TextBox();
			this.btn_fibo = new System.Windows.Forms.Button();
			this.lbl_fibo = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.label10 = new System.Windows.Forms.Label();
			this.label11 = new System.Windows.Forms.Label();
			this.label12 = new System.Windows.Forms.Label();
			this.label13 = new System.Windows.Forms.Label();
			this.label14 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// txt_sayi1
			// 
			this.txt_sayi1.Location = new System.Drawing.Point(32, 37);
			this.txt_sayi1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
			this.txt_sayi1.Name = "txt_sayi1";
			this.txt_sayi1.Size = new System.Drawing.Size(48, 22);
			this.txt_sayi1.TabIndex = 0;
			// 
			// txt_sayi2
			// 
			this.txt_sayi2.Location = new System.Drawing.Point(116, 37);
			this.txt_sayi2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
			this.txt_sayi2.Name = "txt_sayi2";
			this.txt_sayi2.Size = new System.Drawing.Size(48, 22);
			this.txt_sayi2.TabIndex = 0;
			// 
			// txt_sayi3
			// 
			this.txt_sayi3.Location = new System.Drawing.Point(216, 37);
			this.txt_sayi3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
			this.txt_sayi3.Name = "txt_sayi3";
			this.txt_sayi3.Size = new System.Drawing.Size(48, 22);
			this.txt_sayi3.TabIndex = 0;
			// 
			// btn_sonuc
			// 
			this.btn_sonuc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.btn_sonuc.ForeColor = System.Drawing.Color.Brown;
			this.btn_sonuc.Location = new System.Drawing.Point(17, 78);
			this.btn_sonuc.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
			this.btn_sonuc.Name = "btn_sonuc";
			this.btn_sonuc.Size = new System.Drawing.Size(87, 36);
			this.btn_sonuc.TabIndex = 1;
			this.btn_sonuc.Text = "Hesapla";
			this.btn_sonuc.UseVisualStyleBackColor = true;
			this.btn_sonuc.Click += new System.EventHandler(this.btn_sonuc_Click);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label1.Location = new System.Drawing.Point(28, 13);
			this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(48, 15);
			this.label1.TabIndex = 2;
			this.label1.Text = "1. SAYI";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label2.Location = new System.Drawing.Point(112, 13);
			this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(48, 15);
			this.label2.TabIndex = 2;
			this.label2.Text = "2. SAYI";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label3.Location = new System.Drawing.Point(213, 13);
			this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(48, 15);
			this.label3.TabIndex = 2;
			this.label3.Text = "3. SAYI";
			// 
			// lbl_sonuc
			// 
			this.lbl_sonuc.AutoSize = true;
			this.lbl_sonuc.BackColor = System.Drawing.Color.Crimson;
			this.lbl_sonuc.Enabled = false;
			this.lbl_sonuc.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.lbl_sonuc.Font = new System.Drawing.Font("Microsoft Himalaya", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.lbl_sonuc.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.lbl_sonuc.Location = new System.Drawing.Point(324, 38);
			this.lbl_sonuc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.lbl_sonuc.Name = "lbl_sonuc";
			this.lbl_sonuc.Size = new System.Drawing.Size(21, 19);
			this.lbl_sonuc.TabIndex = 2;
			this.lbl_sonuc.Text = "...";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label4.Location = new System.Drawing.Point(325, 13);
			this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(51, 15);
			this.label4.TabIndex = 2;
			this.label4.Text = "SONUÇ";
			this.label4.Click += new System.EventHandler(this.label4_Click);
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label5.Location = new System.Drawing.Point(88, 34);
			this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(24, 25);
			this.label5.TabIndex = 2;
			this.label5.Text = "+";
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label6.Location = new System.Drawing.Point(188, 39);
			this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(20, 25);
			this.label6.TabIndex = 2;
			this.label6.Text = "*";
			// 
			// button2
			// 
			this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.button2.ForeColor = System.Drawing.Color.Brown;
			this.button2.Location = new System.Drawing.Point(22, 313);
			this.button2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(155, 39);
			this.button2.TabIndex = 4;
			this.button2.Text = "Çarpım Tablosu";
			this.button2.UseVisualStyleBackColor = true;
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// button1
			// 
			this.button1.BackColor = System.Drawing.Color.Snow;
			this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.button1.ForeColor = System.Drawing.Color.Brown;
			this.button1.Location = new System.Drawing.Point(17, 211);
			this.button1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(294, 39);
			this.button1.TabIndex = 3;
			this.button1.Text = "1 den 200 e kadar olan sayıları getir";
			this.button1.UseVisualStyleBackColor = false;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// btn_dosya
			// 
			this.btn_dosya.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.btn_dosya.ForeColor = System.Drawing.Color.Brown;
			this.btn_dosya.Location = new System.Drawing.Point(22, 411);
			this.btn_dosya.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
			this.btn_dosya.Name = "btn_dosya";
			this.btn_dosya.Size = new System.Drawing.Size(100, 32);
			this.btn_dosya.TabIndex = 5;
			this.btn_dosya.Text = "Dosya Seç";
			this.btn_dosya.UseVisualStyleBackColor = true;
			this.btn_dosya.Click += new System.EventHandler(this.btn_dosya_Click);
			// 
			// openFileDialog1
			// 
			this.openFileDialog1.FileName = "openFileDialog1";
			// 
			// txt_fibosayi
			// 
			this.txt_fibosayi.Location = new System.Drawing.Point(22, 533);
			this.txt_fibosayi.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
			this.txt_fibosayi.Name = "txt_fibosayi";
			this.txt_fibosayi.Size = new System.Drawing.Size(92, 22);
			this.txt_fibosayi.TabIndex = 6;
			// 
			// btn_fibo
			// 
			this.btn_fibo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.btn_fibo.ForeColor = System.Drawing.Color.Brown;
			this.btn_fibo.Location = new System.Drawing.Point(22, 563);
			this.btn_fibo.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
			this.btn_fibo.Name = "btn_fibo";
			this.btn_fibo.Size = new System.Drawing.Size(142, 25);
			this.btn_fibo.TabIndex = 7;
			this.btn_fibo.Text = "Fibonacci Hesapla";
			this.btn_fibo.UseVisualStyleBackColor = true;
			this.btn_fibo.Click += new System.EventHandler(this.btn_fibo_Click);
			// 
			// lbl_fibo
			// 
			this.lbl_fibo.AutoSize = true;
			this.lbl_fibo.BackColor = System.Drawing.Color.Crimson;
			this.lbl_fibo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.lbl_fibo.Location = new System.Drawing.Point(148, 536);
			this.lbl_fibo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.lbl_fibo.Name = "lbl_fibo";
			this.lbl_fibo.Size = new System.Drawing.Size(109, 17);
			this.lbl_fibo.TabIndex = 8;
			this.lbl_fibo.Text = "Fibonacci Sayısı";
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.BackColor = System.Drawing.Color.YellowGreen;
			this.label7.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label7.Location = new System.Drawing.Point(14, 160);
			this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(849, 38);
			this.label7.TabIndex = 9;
			this.label7.Text = resources.GetString("label7.Text");
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.BackColor = System.Drawing.Color.YellowGreen;
			this.label8.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label8.Location = new System.Drawing.Point(18, 282);
			this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(282, 19);
			this.label8.TabIndex = 10;
			this.label8.Text = "Çarpım tablosu oluşturmak için tıklayın.";
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.BackColor = System.Drawing.Color.YellowGreen;
			this.label9.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label9.Location = new System.Drawing.Point(18, 382);
			this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(815, 19);
			this.label9.TabIndex = 11;
			this.label9.Text = "İçinde ondalık ve tam sayıaların bulunduğu metin dosyasını seçin ve veriler büyük" +
    "ten küçüğe sıralı bir şekilde gelecektir.";
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.BackColor = System.Drawing.Color.YellowGreen;
			this.label10.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label10.Location = new System.Drawing.Point(18, 478);
			this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(426, 19);
			this.label10.TabIndex = 12;
			this.label10.Text = "Girilen sayı fibonacci dizisi sıralamasında ki sayıyı verecektir. ";
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.BackColor = System.Drawing.Color.Goldenrod;
			this.label11.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label11.ForeColor = System.Drawing.Color.Black;
			this.label11.Location = new System.Drawing.Point(19, 512);
			this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(89, 15);
			this.label11.TabIndex = 13;
			this.label11.Text = "SAYI GİRİNİZ:";
			// 
			// label12
			// 
			this.label12.AutoSize = true;
			this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label12.Location = new System.Drawing.Point(282, 35);
			this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(24, 25);
			this.label12.TabIndex = 14;
			this.label12.Text = "=";
			// 
			// label13
			// 
			this.label13.AutoSize = true;
			this.label13.Font = new System.Drawing.Font("Times New Roman", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label13.Location = new System.Drawing.Point(171, 28);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(23, 31);
			this.label13.TabIndex = 15;
			this.label13.Text = ")";
			// 
			// label14
			// 
			this.label14.AutoSize = true;
			this.label14.Font = new System.Drawing.Font("Times New Roman", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label14.Location = new System.Drawing.Point(8, 30);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(23, 31);
			this.label14.TabIndex = 15;
			this.label14.Text = "(";
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.Goldenrod;
			this.ClientSize = new System.Drawing.Size(905, 647);
			this.Controls.Add(this.label14);
			this.Controls.Add(this.label13);
			this.Controls.Add(this.label12);
			this.Controls.Add(this.label11);
			this.Controls.Add(this.label10);
			this.Controls.Add(this.label9);
			this.Controls.Add(this.label8);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.lbl_fibo);
			this.Controls.Add(this.btn_fibo);
			this.Controls.Add(this.txt_fibosayi);
			this.Controls.Add(this.btn_dosya);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.lbl_sonuc);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.btn_sonuc);
			this.Controls.Add(this.txt_sayi3);
			this.Controls.Add(this.txt_sayi2);
			this.Controls.Add(this.txt_sayi1);
			this.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TextBox txt_sayi1;
		private System.Windows.Forms.TextBox txt_sayi2;
		private System.Windows.Forms.TextBox txt_sayi3;
		private System.Windows.Forms.Button btn_sonuc;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label lbl_sonuc;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button btn_dosya;
		private System.Windows.Forms.OpenFileDialog openFileDialog1;
		private System.Windows.Forms.TextBox txt_fibosayi;
		private System.Windows.Forms.Button btn_fibo;
		private System.Windows.Forms.Label lbl_fibo;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.Label label14;
	}
}

