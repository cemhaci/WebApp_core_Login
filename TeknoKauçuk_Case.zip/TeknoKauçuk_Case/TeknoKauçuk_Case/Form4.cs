﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TeknoKauçuk_Case
{
	public partial class Form4 : Form
	{
		public Form4()
		{
			InitializeComponent();
		}

		private void Form4_Load(object sender, EventArgs e)
		{
			if (openFileDialog1.ShowDialog() == DialogResult.OK)
			{

				string row = openFileDialog1.FileName;
				string[] lines = File.ReadAllLines(row);
				List<double> numbers = new List<double>();
				
				foreach (string line in lines)
				{
					string[] parts = Regex.Split(line, @"\s+");

					numbers.AddRange(parts.Select(x => double.Parse(x)));
				}
				numbers.Sort();
				numbers.Reverse();

				txt_write.Text = string.Join(Environment.NewLine, numbers);

			}
		}

		private void txt_write_TextChanged(object sender, EventArgs e)
		{

		}
	}
}
