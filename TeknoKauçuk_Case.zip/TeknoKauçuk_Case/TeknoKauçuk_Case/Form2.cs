﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TeknoKauçuk_Case
{
	public partial class Form2 : Form
	{
		public Form2()
		{
			InitializeComponent();
		}

		private void btn_carpım_Click(object sender, EventArgs e)
		{
			tableLayoutPanel1.Controls.Clear();
			if (!string.IsNullOrEmpty(txt_veri.Text) && !txt_veri.Text.Any(c=>!Char.IsDigit(c)))
			{
				int veri = Convert.ToInt32(txt_veri.Text);
				
            if (veri < 16)
			{
				tableLayoutPanel1.ColumnCount = veri + 1;
				tableLayoutPanel1.RowCount = veri + 1;


				for (int i = 1; i < veri + 1; i++)
				{


					for (int x = 1; x < veri + 1; x++)
					{
						Label lbl = new Label();
						lbl.AutoSize= true;
						lbl.Font = new Font("Arial", 12, FontStyle.Regular);
						lbl.Size = new Size(60, 35);
						int sonuc = (i * x);
						lbl.Text = sonuc.ToString();
						tableLayoutPanel1.Controls.Add(lbl, i, x);
					}
				}
			}
			else
				MessageBox.Show("Lütfen 15 veya 15 den küçük sayı giriniz.", "Uyarı", MessageBoxButtons.OK,MessageBoxIcon.Warning);
				
            }
			else
			MessageBox.Show("lütfen sayısal bir veri giriniz.","Uyarı",MessageBoxButtons.OK,MessageBoxIcon.Warning);
		}

		private void Form2_Load(object sender, EventArgs e)
		{

		}
	}
}
