﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace TeknoKauçuk_Case
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void btn_sonuc_Click(object sender, EventArgs e)
		{
			int s1, s2, s3;
			try
			{
				s1 = Convert.ToInt32(txt_sayi1.Text);
				s2 = Convert.ToInt32(txt_sayi2.Text);
				s3 = Convert.ToInt32(txt_sayi3.Text);
				int sonuc = (s1 + s2) * s3;
				lbl_sonuc.Text = sonuc.ToString();
			}
			catch (Exception)
			{
				MessageBox.Show("lütfen sayısal bir veri giriniz.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
			}

		}

		private void txt_sonuc_TextChanged(object sender, EventArgs e)
		{

		}

		private void label4_Click(object sender, EventArgs e)
		{

		}

		private void button1_Click(object sender, EventArgs e)
		{
			Form3 form= new Form3();
			form.Show();
		}

		private void button2_Click(object sender, EventArgs e)
		{
			Form2 form2= new Form2();
			form2.Show();
		}

		private void btn_dosya_Click(object sender, EventArgs e)
		{
			Form4 form4 = new Form4();
			form4.Show();
			
		}

		private void btn_fibo_Click(object sender, EventArgs e)
		{
			if (!string.IsNullOrEmpty(txt_fibosayi.Text) && !txt_fibosayi.Text.Any(c => !Char.IsDigit(c)))
			{
              int n = Convert.ToInt32(txt_fibosayi.Text);
			
			if (n == 1)
			{
				lbl_fibo.Text = "0";
				return;
			}
		
			else if (n == 2)
			{
				lbl_fibo.Text = "1";
				return;
			}
			else if (n == 3)
			{
				lbl_fibo.Text = "1";
				return;
			}
			else if (n < 1)
			{
				MessageBox.Show("Lütfen sayma sayılarından bir sayı yazınız.","Uyarı",MessageBoxButtons.OK,MessageBoxIcon.Warning);
				return;
			}
			
			
            int a = 0;
			int b = 1;
			for (int i = 3; i <= n; i++)
			{
				int x = a;
				a = b;
				b = x + b;
			}

			lbl_fibo.Text = b.ToString();
				
			}
				
			else
				MessageBox.Show("lütfen sayısal bir veri giriniz.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);

		}
	}
}
