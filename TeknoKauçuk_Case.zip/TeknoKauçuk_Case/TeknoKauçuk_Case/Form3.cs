﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TeknoKauçuk_Case
{
	public partial class Form3 : Form
	{
		public Form3()
		{
			InitializeComponent();
		}

		

		private void Form3_Load(object sender, EventArgs e)
		{
			for (int i = 1; i < 201; i++)
			{
				Label lbl = new Label();
				//lbl.AutoSize= true;
				lbl.Font = new Font("Arial", 12, FontStyle.Regular);
				lbl.Size = new Size(60, 35);



				if (i % 3 == 0 && i % 5 == 0)
				{
					if (i > 100)
					{
						lbl.Text = "zagzig";
					}
					else
						lbl.Text = "zigzag";

				}
				else if (i % 5 == 0)
				{
					lbl.Text = "zag";
				}
				else if (i % 3 == 0)
				{
					lbl.Text = "zig";

				}
				else
					lbl.Text = i.ToString();
				flowLayoutPanel1.Controls.Add(lbl);
			}
		}
	}
}
